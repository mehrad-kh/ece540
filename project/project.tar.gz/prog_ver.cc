/* Generated automatically by the SUIF makefiles. */

char *prog_ver_string = "(unnumbered test version)";
char *prog_who_string = "compiled Thu Apr 10 19:45:51 EDT 2014 by moham356 on ug235.eecg";
char *prog_suif_string = "1.1.2";
