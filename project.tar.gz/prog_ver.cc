/* Generated automatically by the SUIF makefiles. */

char *prog_ver_string = "(unnumbered test version)";
char *prog_who_string = "compiled Wed Apr 9 12:25:18 EDT 2014 by moham356 on ug202.eecg";
char *prog_suif_string = "1.1.2";
