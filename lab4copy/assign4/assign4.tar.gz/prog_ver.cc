/* Generated automatically by the SUIF makefiles. */

char *prog_ver_string = "(unnumbered test version)";
char *prog_who_string = "compiled Mon Mar 10 19:35:29 EDT 2014 by moham356 on ug246.eecg";
char *prog_suif_string = "1.1.2";
