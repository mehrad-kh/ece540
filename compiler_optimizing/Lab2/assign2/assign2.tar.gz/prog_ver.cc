/* Generated automatically by the SUIF makefiles. */

char *prog_ver_string = "(unnumbered test version)";
char *prog_who_string = "compiled Mon Feb 3 19:38:51 EST 2014 by moham356 on ug238.eecg";
char *prog_suif_string = "1.1.2";
