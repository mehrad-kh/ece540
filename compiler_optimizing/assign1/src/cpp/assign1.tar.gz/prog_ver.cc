/* Generated automatically by the SUIF makefiles. */

char *prog_ver_string = "(unnumbered test version)";
char *prog_who_string = "compiled Mon Jan 20 19:40:18 EST 2014 by moham356 on ug153.eecg";
char *prog_suif_string = "1.1.2";
